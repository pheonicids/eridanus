document.addEventListener('DOMContentLoaded', () => {
    const flame = document.getElementById('flame');
    const smoke = document.getElementById('smoke');
    const backgroundMusic = document.getElementById('background-music');

    // Play background music
    backgroundMusic.play();

    let flameOpacity = 1; // Initial opacity of the flame
    const fadeStep = 0.01; // Amount to decrease the opacity by on each blow
    const recoveryStep = 0.01; // Amount to increase the opacity by when no blow is detected
    const threshold = 30; // Threshold for detecting a blow

    // Check if the browser supports getUserMedia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const analyser = audioContext.createAnalyser();
            const microphone = audioContext.createMediaStreamSource(stream);
            const javascriptNode = audioContext.createScriptProcessor(2048, 1, 1);

            analyser.smoothingTimeConstant = 0.8;
            analyser.fftSize = 1024;

            microphone.connect(analyser);
            analyser.connect(javascriptNode);
            javascriptNode.connect(audioContext.destination);

            let blowing = false;

            javascriptNode.onaudioprocess = () => {
                const array = new Uint8Array(analyser.frequencyBinCount);
                analyser.getByteFrequencyData(array);
                const average = array.reduce((a, b) => a + b) / array.length;

                if (average > threshold) {
                    blowing = true;
                } else {
                    blowing = false;
                }
            };

            const updateEffects = () => {
                if (blowing) {
                    flameOpacity = Math.max(0, flameOpacity - fadeStep);
                } else {
                    flameOpacity = Math.min(1, flameOpacity + recoveryStep);
                }

                flame.style.opacity = flameOpacity;
                smoke.style.opacity = 1 - flameOpacity; // Inverse relationship to flame

                requestAnimationFrame(updateEffects);
            };

            updateEffects();
        }).catch(err => {
            console.error('The following error occurred: ' + err);
        });
    } else {
        console.error('getUserMedia not supported on your browser!');
    }
});